package patoelcerdo;

import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.QuadCurve;
import javafx.scene.shape.QuadCurveTo;
import javafx.scene.shape.StrokeType;
import javafx.stage.Stage;
import javafx.util.Duration;

public class PatoElCerdo extends Application {
    
    @Override
    public void start(Stage primaryStage) {
       Button btn1 = new Button("Pintar cuerpo");
       Button btn2 = new Button("Pintar pezuñas");
       Button btn3 = new Button("Pintar trompa");
       btn1.setStyle("-fx-background-radius: 12;\n" +"-fx-padding: 8;\n" +"-fx-shadow-highlight-color: f0f0f0;\n" +"-fx-body-color: linear-gradient(from 0em 0em to 0em 2.083333em, white, #D7D7D7, white);");
       btn2.setStyle("-fx-background-radius: 12;\n" +"-fx-padding: 8;\n" +"-fx-shadow-highlight-color: f0f0f0;\n" +"-fx-body-color: linear-gradient(from 0em 0em to 0em 2.083333em, white, #D7D7D7, white);");
       btn3.setStyle("-fx-background-radius: 12;\n" +"-fx-padding: 8;\n" +"-fx-shadow-highlight-color: f0f0f0;\n" +"-fx-body-color: linear-gradient(from 0em 0em to 0em 2.083333em, white, #D7D7D7, white);");
       
       btn1.setLayoutX(99);
       btn1.setLayoutY(535);
       
       btn2.setLayoutX(271);
       btn2.setLayoutY(535);
       
       btn3.setLayoutX(425);
       btn3.setLayoutY(535);
       Pane root = new Pane();
       Image imagen = new Image("fondo.jpg");
       ImageView fondo = new ImageView();
       fondo.setImage(imagen);
       fondo.setFitWidth(700);
       fondo.setFitHeight(600);
       //fondo.setOpacity(0.5);
       
       root.setOnMouseClicked(evt->{
           double x = evt.getX();
           double y = evt.getY();
           System.out.println("Coordenadas " + "X: "+ x + "Y: " + y);
       });
       
       Path cuerpo = new Path();
       MoveTo moveTo1 = new MoveTo(143, 159);
       QuadCurveTo curva1 = new QuadCurveTo(179, 135, 234, 130);
       QuadCurveTo curva2 = new QuadCurveTo(247, 113, 265, 103);
       QuadCurveTo curva3 = new QuadCurveTo(280, 100, 293, 111);
       QuadCurveTo curva4 = new QuadCurveTo(304, 111, 315, 110);
       QuadCurveTo curva5 = new QuadCurveTo(325, 130, 317, 160);
       QuadCurveTo curva6 = new QuadCurveTo(334, 176, 350, 196);
       QuadCurveTo curva7 = new QuadCurveTo(373, 194, 402, 195);
       QuadCurveTo curva8 = new QuadCurveTo(433, 196, 464, 199);
       QuadCurveTo curva9 = new QuadCurveTo(496, 206, 523, 217);
       QuadCurveTo curva10 = new QuadCurveTo(548, 232, 567, 258);
       QuadCurveTo curva11 = new QuadCurveTo(590, 262, 606, 279);
       QuadCurveTo curva12 = new QuadCurveTo(622, 306, 615, 336);
       QuadCurveTo curva13 = new QuadCurveTo(642, 339, 656, 356);
       QuadCurveTo curva14 = new QuadCurveTo(658, 365, 646, 373);
       QuadCurveTo curva15 = new QuadCurveTo(622, 375, 583, 377);
       QuadCurveTo curva16 = new QuadCurveTo(581, 388, 576, 397);
       QuadCurveTo curva17 = new QuadCurveTo(597, 400, 622, 409);
       QuadCurveTo curva18 = new QuadCurveTo(638, 430, 613, 440);
       QuadCurveTo curva19 = new QuadCurveTo(597, 443, 582, 443);
       LineTo linea1 = new LineTo(219, 443);
       QuadCurveTo curva20 = new QuadCurveTo(186, 448, 152, 447);
       QuadCurveTo curva21 = new QuadCurveTo(113, 438, 97, 419);
       QuadCurveTo curva22 = new QuadCurveTo(77, 375, 97, 319);
       QuadCurveTo curva23 = new QuadCurveTo(76, 281, 88, 230);
       QuadCurveTo curva24 = new QuadCurveTo(62, 202, 70, 177);
       QuadCurveTo curva25 = new QuadCurveTo(78, 175, 84, 162);
       QuadCurveTo curva26 = new QuadCurveTo(107, 145, 143, 159);
       cuerpo.getElements().addAll(moveTo1,curva1,curva2,curva3,curva4,curva5,
                                   curva6, curva7, curva8,curva9, curva10, curva11,
                                   curva12, curva13, curva14, curva15, curva16,
                                   curva17, curva18, curva19, linea1,curva20, curva21,
                                   curva22, curva23, curva24, curva25, curva26);
       cuerpo.setStrokeWidth(2.5);
       
       
       
       Path pezunia1 = new Path();
       MoveTo moveTo2 = new MoveTo(627, 337);
       QuadCurveTo cur1 = new QuadCurveTo(628, 354, 622, 374);
       LineTo linea2 = new LineTo(643, 373);
       QuadCurveTo cur2 = new QuadCurveTo(666, 361, 644, 344);
       QuadCurveTo cur3 = new QuadCurveTo(634, 339, 627, 337);
       pezunia1.getElements().addAll(moveTo2,cur1, linea2, cur2, cur3);
       pezunia1.setStrokeWidth(2.5);
      
       
       Path pezunia2 = new Path();
       MoveTo moveTo3 = new MoveTo(596, 401);
       QuadCurveTo cur4 = new QuadCurveTo(584, 421, 581, 441);
       QuadCurveTo cur5 = new QuadCurveTo(596, 442, 610, 439);
       QuadCurveTo cur6 = new QuadCurveTo(638, 428, 621, 409);
       pezunia2.getElements().addAll(moveTo3, cur4, cur5, cur6);
       pezunia2.setStrokeWidth(2.5);
       
       
       Path pezunia3 = new Path();
       MoveTo moveTo4 = new MoveTo(86, 376);
       QuadCurveTo cur7 = new QuadCurveTo(87, 350, 96, 320);
       QuadCurveTo cur8 = new QuadCurveTo(110, 307, 126, 337);
       QuadCurveTo cur9 = new QuadCurveTo(132, 353, 135, 378);
       QuadCurveTo cur10 = new QuadCurveTo(113, 388, 85, 377);
       pezunia3.getElements().addAll(moveTo4,cur7,cur8,cur9, cur10);
       pezunia3.setStrokeWidth(2.5);
       
       
       Path pezunia4 = new Path();
       MoveTo moveTo5 = new MoveTo(367, 345);
       QuadCurveTo cur11 = new QuadCurveTo(387, 349, 415, 342);
       QuadCurveTo cur12 = new QuadCurveTo(385, 450, 367, 345);
       pezunia4.getElements().addAll(moveTo5, cur11,cur12);
       pezunia4.setStrokeWidth(2.5);
       
       QuadCurve qc1 = new QuadCurve(189, 225, 201, 204, 226, 211);
       qc1.setStrokeWidth(2.5);
       qc1.setStroke(Paint.valueOf("#030201"));
       qc1.setFill(Paint.valueOf("#fbdbe3"));
       
       
       Path trompa = new Path();
       MoveTo moveTo6 = new MoveTo(183, 290);
       QuadCurveTo curva27 = new QuadCurveTo(179, 267, 193, 229);
       QuadCurveTo curva28 = new QuadCurveTo(203, 206, 230, 216);
       QuadCurveTo curva29 = new QuadCurveTo(252, 227, 272, 243);
       QuadCurveTo curva30 = new QuadCurveTo(276, 253, 273, 261);
       QuadCurveTo curva31 = new QuadCurveTo(256, 268, 232, 268);
       QuadCurveTo curva32 = new QuadCurveTo(218, 275, 205, 286);
       QuadCurveTo curva33 = new QuadCurveTo(192, 299, 182, 290);
       trompa.getElements().addAll(moveTo6, curva27, curva28, curva29, curva30, curva31,curva32,curva33);
       trompa.setStrokeWidth(2.5);
       
       QuadCurve qc = new QuadCurve(261, 286, 247, 315, 218, 305);
       qc.setStrokeWidth(2.5);
       qc.setStroke(Paint.valueOf("#030201"));
       qc.setFill(Paint.valueOf("#fbdbe3"));
       
       Path boca = new Path();
       MoveTo moveTo7 = new MoveTo(262, 266);
       QuadCurveTo curva34 = new QuadCurveTo(255, 276, 250, 289);
       QuadCurveTo curva35 = new QuadCurveTo(242, 303, 225, 297); 
       QuadCurveTo curva36 = new QuadCurveTo(215, 291, 204, 287);
       LineTo linea3 = new LineTo(229, 267);
       LineTo linea4 = new LineTo(261, 264);
       boca.getElements().addAll(moveTo7, curva34, curva35, curva36, linea3, linea4);
       boca.setStrokeWidth(2.5);
       
       Path lengua = new Path();
       MoveTo moveTo8 = new MoveTo(250, 284);
       QuadCurveTo curva37 = new QuadCurveTo(242, 303, 225, 297);
       QuadCurveTo curva38 = new QuadCurveTo(235, 288, 250, 284);
       lengua.getElements().addAll(moveTo8, curva37, curva38);
       lengua.setStrokeWidth(2.5);
       
       QuadCurve qc2 = new QuadCurve(568, 258, 602, 315, 583, 377);
       qc2.setStrokeWidth(2.5);
       qc2.setStroke(Paint.valueOf("#030201"));
       qc2.setFill(Paint.valueOf("#fbdbe3"));
       
       Line ln1 = new Line(416, 340, 423, 309);
       ln1.setStrokeWidth(2.5);
       Line ln2 = new Line(367, 344, 362, 307);
       ln2.setStrokeWidth(2.5);
       Line ln3 = new Line(164, 385, 133, 367);
       ln3.setStrokeWidth(2.5);
       Line ln4 = new Line(138, 391, 134, 377);
       ln4.setStrokeWidth(2.5);
       Line ln5 = new Line(142, 160, 125, 174);
       ln5.setStrokeWidth(2.5);
       Line ln6 = new Line(235, 131, 259, 132);
       ln6.setStrokeWidth(2.5);
       
       QuadCurve qc3 = new QuadCurve(349, 196, 364, 224, 365, 255);
       qc3.setStrokeWidth(2.5);
       qc3.setStroke(Paint.valueOf("#030201"));
       qc3.setFill(Paint.valueOf("#fbdbe3"));
       
       QuadCurve qc4 = new QuadCurve(159, 269, 184, 288, 195, 318);
       qc4.setStrokeWidth(2.5);
       qc4.setStroke(Paint.valueOf("#030201"));
       qc4.setFill(Paint.valueOf("#fbdbe3"));
       
       QuadCurve qc5 = new QuadCurve(270, 210, 271, 246, 288, 269);
       qc5.setStrokeWidth(2.5);
       qc5.setStroke(Paint.valueOf("#030201"));
       qc5.setFill(Paint.valueOf("#fbdbe3"));
       
       QuadCurve qc6 = new QuadCurve(467, 375, 539,338,575, 398);
       qc6.setStrokeWidth(2.5);
       qc6.setStroke(Paint.valueOf("#030201"));
       qc6.setFill(Paint.valueOf("#fbdbe3"));
       
       QuadCurve qc7 = new QuadCurve(109, 168, 107,187,117, 221);
       qc7.setStrokeWidth(2.5);
       qc7.setStroke(Paint.valueOf("#030201"));
       qc7.setFill(Paint.valueOf("#fbdbe3"));
       
       QuadCurve qc8 = new QuadCurve(117, 221, 119,250,89, 229);
       qc8.setStrokeWidth(2.5);
       qc8.setStroke(Paint.valueOf("#030201"));
       qc8.setFill(Paint.valueOf("#fbdbe3"));
       
       QuadCurve qc9 = new QuadCurve(316, 162, 296,200,281, 159);
       qc9.setStrokeWidth(2.5);
       qc9.setStroke(Paint.valueOf("#030201"));
       qc9.setFill(Paint.valueOf("#fbdbe3"));
       
       Line ln7 = new Line(281, 159, 273, 129);
       ln7.setStrokeWidth(2.5);
       
       QuadCurve qc10 = new QuadCurve(105, 315, 98,333,101, 353);
       qc10.setStrokeWidth(2.5);
       qc10.setStroke(Paint.valueOf("#030201"));
       qc10.setFill(Paint.valueOf("#74646c"));
       
       QuadCurve qc11 = new QuadCurve(381, 360, 380,377,385, 395);
       qc11.setStrokeWidth(2.5);
       qc11.setStroke(Paint.valueOf("#030201"));
       qc11.setFill(Paint.valueOf("#74646c"));
       
       QuadCurve qc12 = new QuadCurve(381, 360, 380,377,385, 395);
       qc12.setStrokeWidth(2.5);
       qc12.setStroke(Paint.valueOf("#030201"));
       qc12.setFill(Paint.valueOf("#74646c"));
       
       QuadCurve qc13 = new QuadCurve(624, 426, 617,418,608, 414);
       qc13.setStrokeWidth(2.5);
       qc13.setStroke(Paint.valueOf("#030201"));
       qc13.setFill(Paint.valueOf("#74646c"));
       
       QuadCurve qc14 = new QuadCurve(652, 362, 643,353,638, 351);
       qc14.setStrokeWidth(2.5);
       qc14.setStroke(Paint.valueOf("#030201"));
       qc14.setFill(Paint.valueOf("#74646c"));
       
       Circle circulo1 = new Circle(166, 221, 10, Paint.valueOf("#030201"));
       Circle circulo2 = new Circle(240, 185, 25, Paint.valueOf("#fab3c3"));
       Circle circulo3 = new Circle(239, 191, 10, Paint.valueOf("#030201"));
        Ellipse elipse1 = new Ellipse(204, 259, 5, 10);
        Ellipse elipse2 = new Ellipse(237, 241, 10, 5);
        
        btn1.setOnMouseClicked(evt->{
           cuerpo.setFill(Paint.valueOf("#fbdbe3"));       
       });
        
         btn2.setOnMouseClicked(evt->{
           pezunia1.setFill(Paint.valueOf("#74646c"));
           pezunia2.setFill(Paint.valueOf("#74646c"));
           pezunia3.setFill(Paint.valueOf("#74646c"));
           pezunia4.setFill(Paint.valueOf("74646c"));
       });
         btn3.setOnMouseClicked(evt->{
           trompa.setFill(Paint.valueOf("#ed6290"));
           boca.setFill(Paint.valueOf("#864156"));
           lengua.setFill(Paint.valueOf("#ed6290"));
       });
         
         //Animacion
         Ellipse eli = new Ellipse(20, 10);
         eli.setFill(Paint.valueOf("#E6E6E6"));
         eli.setLayoutX(100);
         eli.setLayoutY(100);
         
         RotateTransition rt = new RotateTransition(Duration.seconds(3), eli);
         rt.setByAngle(180);
         rt.setCycleCount(4);
         rt.setAutoReverse(true);
         rt.play();
        
         //
       root.getChildren().addAll(fondo,cuerpo,pezunia1,pezunia2, pezunia3, pezunia4,qc1, trompa,qc, boca,lengua,
                                 ln1,ln2, ln3,ln4,ln5,ln6,qc2,qc3,qc4,qc5,qc6,qc7,qc8,qc9,ln7, qc10,qc11,
                                 qc12, qc13,qc14, circulo1,circulo2,circulo3,elipse1,elipse2,btn1,btn2,btn3,eli); 
        Scene scene = new Scene(root, 700, 600);
        
        primaryStage.setTitle("Dibujo");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}